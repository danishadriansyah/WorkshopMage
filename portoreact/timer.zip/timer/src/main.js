import './style.css'

// Timer variables
let timerInterval = null;
let totalSeconds = 0;
let isRunning = false;

document.querySelector('#app').innerHTML = `
  <div class="timer-container">
    <h1>⏰ Timer Countdown</h1>
    
    <div class="timer-display">
      <span id="minutes">00</span>:<span id="seconds">00</span>
    </div>
    
    <div class="timer-inputs">
      <div class="input-group">
        <label for="minutesInput">Menit:</label>
        <input type="number" id="minutesInput" min="0" max="59" value="5" />
      </div>
      <div class="input-group">
        <label for="secondsInput">Detik:</label>
        <input type="number" id="secondsInput" min="0" max="59" value="0" />
      </div>
    </div>
    
    <div class="timer-controls">
      <button id="startBtn" class="btn btn-start">Start</button>
      <button id="pauseBtn" class="btn btn-pause" disabled>Pause</button>
      <button id="resetBtn" class="btn btn-reset">Reset</button>
    </div>
    
    <div class="progress-bar">
      <div id="progress" class="progress-fill"></div>
    </div>
  </div>
`

// Get DOM elements
const minutesDisplay = document.getElementById('minutes');
const secondsDisplay = document.getElementById('seconds');
const minutesInput = document.getElementById('minutesInput');
const secondsInput = document.getElementById('secondsInput');
const startBtn = document.getElementById('startBtn');
const pauseBtn = document.getElementById('pauseBtn');
const resetBtn = document.getElementById('resetBtn');
const progressBar = document.getElementById('progress');

let initialTotalSeconds = 0;

// Update display
function updateDisplay() {
  const mins = Math.floor(totalSeconds / 60);
  const secs = totalSeconds % 60;
  minutesDisplay.textContent = mins.toString().padStart(2, '0');
  secondsDisplay.textContent = secs.toString().padStart(2, '0');
  
  // Update progress bar
  if (initialTotalSeconds > 0) {
    const progress = ((initialTotalSeconds - totalSeconds) / initialTotalSeconds) * 100;
    progressBar.style.width = progress + '%';
  }
}

// Start timer
function startTimer() {
  if (!isRunning) {
    const mins = parseInt(minutesInput.value) || 0;
    const secs = parseInt(secondsInput.value) || 0;
    
    if (totalSeconds === 0) {
      totalSeconds = mins * 60 + secs;
      initialTotalSeconds = totalSeconds;
    }
    
    if (totalSeconds <= 0) {
      alert('Mohon masukkan waktu yang valid!');
      return;
    }
    
    isRunning = true;
    startBtn.disabled = true;
    pauseBtn.disabled = false;
    minutesInput.disabled = true;
    secondsInput.disabled = true;
    
    timerInterval = setInterval(() => {
      totalSeconds--;
      updateDisplay();
      
      if (totalSeconds <= 0) {
        clearInterval(timerInterval);
        isRunning = false;
        startBtn.disabled = false;
        pauseBtn.disabled = true;
        minutesInput.disabled = false;
        secondsInput.disabled = false;
        
        // Timer finished - play sound and show alert
        alert('⏰ Waktu habis!');
        
        // Flash effect
        document.querySelector('.timer-display').style.animation = 'flash 0.5s ease-in-out 3';
      }
    }, 1000);
  }
}

// Pause timer
function pauseTimer() {
  if (isRunning) {
    clearInterval(timerInterval);
    isRunning = false;
    startBtn.disabled = false;
    pauseBtn.disabled = true;
  }
}

// Reset timer
function resetTimer() {
  clearInterval(timerInterval);
  isRunning = false;
  totalSeconds = 0;
  initialTotalSeconds = 0;
  
  startBtn.disabled = false;
  pauseBtn.disabled = true;
  minutesInput.disabled = false;
  secondsInput.disabled = false;
  
  updateDisplay();
  progressBar.style.width = '0%';
  
  // Remove flash animation
  document.querySelector('.timer-display').style.animation = '';
}

// Event listeners
startBtn.addEventListener('click', startTimer);
pauseBtn.addEventListener('click', pauseTimer);
resetBtn.addEventListener('click', resetTimer);

// Initialize display
updateDisplay();
